<?php
/**
 * Message Report Page.
 *
 * @package DAME
 */

namespace DAME\Admin\Pages;

/**
 * Class MessageReport
 */
class MessageReport {

	/**
	 * Initialize the page.
	 */
	public function init(): void {

		add_action( 'admin_head', [ $this, 'hide_menu_link' ] );
	}


	/**
	 * Hide the menu link via CSS.
	 */
	public function hide_menu_link(): void {
		echo '<style>
			a[href="admin.php?page=dame-message-report"],
			li:has(> a[href="admin.php?page=dame-message-report"]) {
				display: none !important;
			}
		</style>';
	}

	/**
	 * Render the report page.
	 */
	public function render(): void {
		if ( ! current_user_can( 'edit_dame_messages' ) ) {
			return;
		}

		$message_id = isset( $_GET['message_id'] ) ? absint( $_GET['message_id'] ) : 0;
		if ( ! $message_id ) {
			echo '<div class="wrap"><p>' . esc_html__( 'Message invalide.', 'dame' ) . '</p></div>';
			return;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'dame_message_opens';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$opens = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE message_id = %d", $message_id ) );

		// Index opens by hash for faster lookup
		$opens_by_hash = array();
		foreach ( $opens as $open ) {
			// Store earliest open if multiple? Or list of opens?
			// The request says "Nom | Email | Date d'ouverture (ou Non lu)".
			// So we prioritize the first open or just 'Yes'.
			// Let's store the object.
			if ( ! isset( $opens_by_hash[ $open->email_hash ] ) ) {
				$opens_by_hash[ $open->email_hash ] = $open;
			}
		}

		$recipients = $this->get_formatted_recipients( $message_id );
		$message = get_post( $message_id );
		?>
		<div class="wrap">
			<h1><?php printf( esc_html__( 'Rapport d\'ouverture : %s', 'dame' ), esc_html( $message->post_title ) ); ?></h1>

			<div class="card">
				<h2><?php esc_html_e( 'Statistiques', 'dame' ); ?></h2>
				<?php
				$total_sent = count( $recipients );
				$unique_opens = count( $opens_by_hash );
				$rate = $total_sent > 0 ? round( ( $unique_opens / $total_sent ) * 100, 2 ) : 0;
				?>
				<p>
					<strong><?php esc_html_e( 'Envoyés :', 'dame' ); ?></strong> <?php echo esc_html( (string) $total_sent ); ?><br>
					<strong><?php esc_html_e( 'Ouvertures uniques :', 'dame' ); ?></strong> <?php echo esc_html( (string) $unique_opens ); ?><br>
					<strong><?php esc_html_e( 'Taux d\'ouverture :', 'dame' ); ?></strong> <?php echo esc_html( (string) $rate ); ?>%
				</p>
			</div>

			<br>

			<table class="widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Nom (Adhérent / Responsable)', 'dame' ); ?></th>
						<th><?php esc_html_e( 'Email', 'dame' ); ?></th>
						<th><?php esc_html_e( 'Date d\'envoi', 'dame' ); ?></th>
						<th><?php esc_html_e( 'Statut', 'dame' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $recipients ) ) : ?>
						<?php foreach ( $recipients as $email => $data ) : ?>
							<?php
							$name      = $data['name'];
							$sent_at   = $data['sent_at'];
							$hash      = md5( mb_strtolower( trim( (string) $email ), 'UTF-8' ) );
							$is_opened = isset( $opens_by_hash[ $hash ] );
							$open_data = $is_opened ? $opens_by_hash[ $hash ] : null;
							?>
							<tr>
								<td><?php echo esc_html( $name ); ?></td>
								<td><?php echo esc_html( (string) $email ); ?></td>
								<td>
									<?php 
									if ( ! empty( $sent_at ) ) {
										echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sent_at . ' UTC' ) ) );
									} elseif ( $is_opened ) {
										// Fallback to open date if send date was not recorded
										echo '<span style="color: #888; font-style: italic;">(' . esc_html__( 'Date inconnue', 'dame' ) . ')</span>';
									} else {
										echo '—';
									}
									?>
								</td>
								<td>
									<?php if ( $is_opened ) : ?>
										<span style="color: green; font-weight: bold;">
											<?php 
											$timestamp = strtotime( $open_data->opened_at . ' UTC' );
											printf( esc_html__( 'Ouvert le %s', 'dame' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) ); 
											?>
										</span>
									<?php else : ?>
										<span style="color: #888;"><?php esc_html_e( 'Non lu', 'dame' ); ?></span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td colspan="3"><?php esc_html_e( 'Aucun destinataire trouvé ou liste non disponible pour ce message.', 'dame' ); ?></td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Retrieves the list of recipients with strictly formatted names and sorted.
	 * 
	 * This method is cumulative: it looks for all posts (Adherents and Contacts) 
	 * that have received this specific message.
	 *
	 * @param int $message_id The message ID.
	 * @return array<string, mixed> Sorted array of recipients [email => formatted_name].
	 */
	private function get_formatted_recipients( $message_id ) {
		$message_id = absint( $message_id );
		if ( ! $message_id ) {
			return array();
		}

		$recipients = array();

		// Formatting helper: NOM (Upper) Prenom (Title)
		$format_name = function( $last, $first ) {
			return mb_strtoupper( (string) $last, 'UTF-8' ) . ' ' . mb_convert_case( (string) $first, MB_CASE_TITLE, 'UTF-8' );
		};

		// Get all posts (Adherents and Contacts) that received this message
		$posts = get_posts( [
			'post_type'      => [ 'adherent', 'dame_contact' ],
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'meta_query'     => [
				[
					'key'     => '_dame_message_received',
					'value'   => (string) $message_id,
					'compare' => '=',
				],
			],
		] );

		foreach ( $posts as $post ) {
			$pid       = $post->ID;
			$post_type = $post->post_type;

			if ( 'adherent' === $post_type ) {
				// Check all possible email sources for this adherent
				for ( $i = 1; $i <= 2; $i++ ) {
					$rep_email = get_post_meta( $pid, "_dame_legal_rep_{$i}_email", true );
					if ( ! empty( $rep_email ) && is_email( (string) $rep_email ) ) {
						$rep_first = get_post_meta( $pid, "_dame_legal_rep_{$i}_first_name", true );
						$rep_last  = get_post_meta( $pid, "_dame_legal_rep_{$i}_last_name", true );
						$name      = $format_name( $rep_last, $rep_first );
						$sent_at   = get_post_meta( $pid, "_dame_message_{$message_id}_sent_at", true );
						$recipients[ (string) $rep_email ] = array( 'name' => $name, 'sent_at' => $sent_at );
					}
				}

				$member_email = get_post_meta( $pid, '_dame_email', true );
				if ( ! empty( $member_email ) && is_email( (string) $member_email ) ) {
					$member_first = get_post_meta( $pid, '_dame_first_name', true );
					$member_last  = get_post_meta( $pid, '_dame_last_name', true );
					$name         = $format_name( $member_last, $member_first );
					$sent_at      = get_post_meta( $pid, "_dame_message_{$message_id}_sent_at", true );
					$recipients[ (string) $member_email ] = array( 'name' => $name, 'sent_at' => $sent_at );
				}
			} elseif ( 'dame_contact' === $post_type ) {
				$contact_email = get_post_meta( $pid, '_dame_contact_email', true );
				if ( ! empty( $contact_email ) && is_email( (string) $contact_email ) ) {
					$contact_last  = get_post_meta( $pid, '_dame_contact_last_name', true );
					$contact_first = get_post_meta( $pid, '_dame_contact_first_name', true );
					$contact_org   = get_post_meta( $pid, '_dame_contact_organization', true );

					$name = $format_name( $contact_last, $contact_first );
					if ( ! empty( $contact_org ) ) {
						$name = (string) $contact_org . ( trim( (string) $name ) ? ' (' . $name . ')' : '' );
					}
					$sent_at = get_post_meta( $pid, "_dame_message_{$message_id}_sent_at", true );
					$recipients[ (string) $contact_email ] = array( 'name' => $name, 'sent_at' => $sent_at );
				}
			}
		}

		// Sort by Name Alphabetically
		uasort( $recipients, fn( $a, $b ) => strcasecmp( (string) $a['name'], (string) $b['name'] ) );

		return $recipients;
	}
}
